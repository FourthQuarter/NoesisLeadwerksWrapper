#pragma once
#include "Leadwerks.h"
#include <UI\UISystem.h>
#include <Input\InputSystem.h>

using namespace Leadwerks;

class App
{
public:
	UISystem*		uiSystem;
	UIRenderer*		uiRenderer;
	InputSystem*	inputSystem;

	Window* window;
	Context* context;
	World* world;
	Camera* camera;

	App();
	virtual ~App();
	
    virtual bool Start();
    virtual bool Loop();
};
