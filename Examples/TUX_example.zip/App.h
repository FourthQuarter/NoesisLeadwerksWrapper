#pragma once
#include "Leadwerks.h"

#include <UI\UISystem.h>
#include <UI\UIRenderer.h>

using namespace Leadwerks;

class App
{
public:
	UISystem*       uiSystem;
	UIRenderer*     uiRenderer;

	Window* window;
	Context* context;
	World* world;
	Camera* camera;

	App();
	virtual ~App();
	
    virtual bool Start();
    virtual bool Loop();
};
